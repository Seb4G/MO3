using UnityEngine;

public class CubeBehaviour : MonoBehaviour 
{

    private float rotationDirection = 0f;
    public float rotationSpeed = 100f;

    public void SetRotationDirection(float direction)
    {
        rotationDirection = direction;
    }
    public void StopRotation()
    {
        rotationDirection = 0f;
    }
    private void Update()
    {
        if (rotationDirection != 0){
            transform.Rotate(0, rotationDirection * rotationSpeed * Time.deltaTime, 0);
        }
    }
}