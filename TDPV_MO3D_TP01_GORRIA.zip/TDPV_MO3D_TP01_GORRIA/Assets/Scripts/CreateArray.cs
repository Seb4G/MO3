using UnityEngine;

public class CreateArray : MonoBehaviour
{
    public GameObject blockPrefab;
    public int N = 3;
    public int M = 4;

    void Start()
    {
        Renderer[] renderers = blockPrefab.GetComponentsInChildren<Renderer>();
        Bounds totalBounds = renderers[0].bounds;

        foreach (Renderer rend in renderers)
        {
            totalBounds.Encapsulate(rend.bounds);
        }

        Vector3 size = totalBounds.size;

        for (int y = 0; y < M; y++)
        {
            for (int x = 0; x < N; x++)
            {
                Vector3 position = new Vector3(x * size.x, y * size.y, 0);
                Instantiate(blockPrefab, position, Quaternion.identity);
            }
        }
    }
}