using UnityEngine;

public class CubeController : MonoBehaviour
{
    public CubeBehaviour cubeBehaviour;
    private bool isStopped = false;

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            isStopped = !isStopped;

            if (isStopped)
                cubeBehaviour.StopRotation();
            return;
        }


        if (!isStopped)
        {
            float input = Input.GetAxis("Horizontal");
            cubeBehaviour.SetRotationDirection(-input);
        }
    }
}